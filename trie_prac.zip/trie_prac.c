#include <stdio.h> 
#include <stdlib.h>
#include <string.h>


typedef struct node {
	struct node* child[26];
	int word;
}node;

node* NewNode();
void InsertNode(node* root, const char* str);
int SearchNode(node* root, const char* str);
void ShowTree(node* now, char* str, int depth);
int delete(node* now, const char* str, int i);
void recommend(node* root, char* str);

void printhead(const char* str) {
	printf("\n==============%s=================\n\n", str);
}

int main() {

	char tmp[20];
	char my[][8] = {
		"below", "blue",
		"ban", "bzak",
		"bzu",  "a",
		"im", "i"
	};
	
	node* root = NewNode();
	
	for (int i = 0; i < 8; i++)
	{
		InsertNode(root, my[i]);
	}
	
	printhead("show all word");
	ShowTree(root, tmp, 0);
	printhead("do i have?... ");
	printf("%s : %s\n", "bz", SearchNode(root, "bz") ? "YES" : "NO");
	printf("%s : %s\n", "blue", SearchNode(root, "blue") ? "YES" : "NO");
	printf("%s : %s\n", "i", SearchNode(root, "i") ? "YES" : "NO");
	
	strcpy(tmp, "blue");
	printf("\n\nafter deleting %s word\n\n", tmp);
	delete(root, tmp, 0);
	
	printhead("show all word");
	ShowTree(root, tmp, 0);
	printhead("do i have?... ");
	
	printf("%s : %s\n", "bz", SearchNode(root, "bz") ? "YES" : "NO");
	printf("%s : %s\n", "blue", SearchNode(root, "blue") ? "YES" : "NO");
	printf("%s : %s\n", "i", SearchNode(root, "i") ? "YES" : "NO");
	
	char help[20] = "bz";
	printf("\n\ndo i have any word start with %s?... \n\n", help);
	recommend(root, help);
}

node* NewNode() { //init 
	node* new_node = (node *)malloc(sizeof(node));
	new_node->word = 0;
	for (int i = 0; i < 26; i++)
	{
		new_node->child[i] = 0;
	}
	return new_node;

}

void InsertNode(node* root, const char* str) {
	int len = strlen(str);
	node* now = root;
	for (int i = 0; i<len; i++) {
		if (!now->child[str[i] - 'a']) now->child[str[i] - 'a'] = NewNode();
		now = now->child[str[i] - 'a'];
	}
	now->word = 1;
}

int SearchNode(node* root, const char* str) {
	int len = strlen(str);
	node* now = root;

	for (int i = 0; i<len; i++) {
		if (!now->child[str[i] - 'a']) return 0;
		now = now->child[str[i] - 'a'];
	}
	return now->word;
}

void ShowTree(node* now, char* str, int depth) {
	if (now->word) printf("%s\n", str);

	for (int i = 0; i<26; i++) {
		if (now->child[i]) {
			str[depth] = i + 'a';
			str[depth + 1] = 0;
			ShowTree(now->child[i], str, depth + 1);
		}
	}
}

int delete(node* now, const char* str, int i) {
	if (i == strlen(str)) {
		int chk = 0;
		for (int i = 0; i<26; i++) {
			if (now->child[i]) chk = 1;
		}
		if (chk) return 0;
		return 1;
	}
	if (now->child[str[i] - 'a']) {
		if (delete(now->child[str[i] - 'a'], str, i + 1)) {
			free(now->child[str[i] - 'a']);
			now->child[str[i] - 'a'] = 0;
			int chk = 0;
			for (int i = 0; i<26; i++) {
				if (now->child[i]) chk = 1;
			}
			if (chk) return 0;
			return 1;
		}
	}
	return 0;
}

void recommend(node* root, char* str) {
	int len = strlen(str);
	node* now = root;

	for (int i = 0; i < len; i++) {
		if (!now->child[str[i] - 'a']) return;
		now = now->child[str[i] - 'a'];
	}
	ShowTree(now, str, len);
}